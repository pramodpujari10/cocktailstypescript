import React from 'react'

const About = () => {
  return (
    <section className="section about-section">
      <div className="section-title">
        about us
      </div>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Libero, ullam, quaerat minus voluptatem ipsum inventore eveniet rem quasi odit sequi delectus unde quam vero provident modi earum soluta cupiditate tenetur.</p>

    </section>
  )
}

export default About
